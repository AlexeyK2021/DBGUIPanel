create definer = alexey@`%` trigger client_check_phone_number
    before insert
    on client
    for each row
BEGIN
IF LENGTH(New.phone_number) != 12 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Wrong phone number format!";
END IF; 

END;

