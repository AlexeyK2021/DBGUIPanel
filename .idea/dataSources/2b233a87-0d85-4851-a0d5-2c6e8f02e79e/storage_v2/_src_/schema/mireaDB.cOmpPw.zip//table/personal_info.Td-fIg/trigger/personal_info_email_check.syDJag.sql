create definer = alexey@`%` trigger personal_info_email_check
    before insert
    on personal_info
    for each row
BEGIN
IF New.login NOT LIKE "%@%" THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Wrong email data format!";
END IF;
END;

