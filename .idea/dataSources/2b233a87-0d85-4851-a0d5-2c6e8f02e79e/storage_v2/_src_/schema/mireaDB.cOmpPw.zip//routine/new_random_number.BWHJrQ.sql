create
    definer = alexey@`%` function new_random_number() returns varchar(25) deterministic
BEGIN
	DECLARE new_phone_number VARCHAR(25);
    
    SET new_phone_number = CONCAT("+79", (SELECT FLOOR(RAND() * 1000000000)));
    WHILE((SELECT client_id FROM client WHERE phone_number = new_phone_number LIMIT 1) != NULL) DO
		SET new_phone_number = CONCAT("+79", (SELECT FLOOR(RAND() * 1000000000)));
    END WHILE;
    
RETURN new_phone_number;
END;

